# Digitalia — Tienda PayPal

Tienda digital con carrito, PayPal y backend Node.js/Express.

## Estructura del proyecto

```text
/
├── public/
│   └── index.html
├── downloads/
│   └── productos/
│       └── (tus productos digitales)
├── server.js
├── package.json
├── .env.example
├── README.md
└── INSTRUCCIONES_RAPIDAS.txt
```

## Productos

La tienda está configurada con estos productos y precios:

| ID | Producto | Precio |
|---|---|---:|
| `peluquerias` | Pack 50 plantillas Instagram para peluquerías | 19 € |
| `excel` | Excel Control de Gastos y Ahorro 5.000 € | 12 € |
| `oposiciones` | Notion para organizar unas oposiciones | 15 € |
| `inmobiliarios` | Kit Canva para inmobiliarios | 24 € |

## Archivos que debes añadir

Coloca los archivos digitales reales dentro de:

```text
downloads/productos/
```

con estos nombres exactos:

```text
pack-peluquerias.pdf
control-gastos.xlsx
notion-oposiciones.zip
kit-inmobiliarios.pdf
```

El ZIP contiene una carpeta preparada para ellos. Los archivos finales deben sustituir/acompañar al archivo `LEEME.txt`.

> Los archivos de ejemplo del proyecto no son sustitutos de tus productos finales. Debes colocar aquí los archivos que quieras entregar a tus compradores.

## Ejecutar en local

Necesitas Node.js.

```bash
npm install
```

Copia `.env.example` como `.env` y configura:

```text
PAYPAL_CLIENT_ID=TU_CLIENT_ID
PAYPAL_CLIENT_SECRET=TU_CLIENT_SECRET
PAYPAL_BASE_URL=https://api-m.paypal.com
PORT=3000
```

Después:

```bash
npm start
```

Abre:

```text
http://localhost:3000
```

## Desplegar en Render

Crea un **Web Service** conectado a este repositorio.

### Build Command

```text
npm install
```

### Start Command

```text
npm start
```

En **Environment Variables**, configura:

```text
PAYPAL_CLIENT_ID
PAYPAL_CLIENT_SECRET
PAYPAL_BASE_URL
```

con:

```text
PAYPAL_BASE_URL=https://api-m.paypal.com
```

**Nunca subas `.env` a GitHub y nunca publiques el Client Secret.**

## PayPal

Para probar sin cobrar dinero real, utiliza primero las credenciales **Sandbox** de PayPal y su entorno Sandbox.

Cuando hayas probado correctamente el flujo de compra, cambia a las credenciales **LIVE** y utiliza:

```text
PAYPAL_BASE_URL=https://api-m.paypal.com
```

El Client ID se utiliza para cargar el botón de PayPal. El Client Secret se utiliza únicamente en el backend.

## Seguridad y producción

- No publiques el Client Secret.
- No subas `.env` a GitHub.
- Usa HTTPS en producción.
- El backend determina el precio del producto; no confíes en importes enviados por el navegador.
- Para una tienda real, se recomienda guardar los productos en almacenamiento privado y entregar enlaces de descarga firmados y con caducidad.
- Considera registrar los pedidos y configurar webhooks de PayPal para una gestión más robusta de pagos.

## Flujo de compra

```text
Cliente
  ↓
Carrito
  ↓
PayPal
  ↓
Backend crea el pedido
  ↓
Cliente autoriza el pago
  ↓
Backend captura y valida el pago
  ↓
Descarga del producto
```
